/*
 * Mid Terms for PWA-1 1304
 */
// Kase Tebo
// Date: Feb 15 2014

(function () {

    var button = document.querySelector(".buttonred");
    button.addEventListener("click", onClick);
    studentNumber = 0;


    var people = [
        {
            Name: "Kase Tebo",
            Address: {Street: "3819 Sutton Place Blvd", City: "Winter Park", State: "Florida"},
            GPA: [3.25, 4.0, 3.75],
            Date: theDate(),
            Average: getAverage([3.25, 4.0, 3.75])

        },
        {
            Name: "Santa Claus",
            Address: {Street: "265 Christmas Ave.", City: "Christmas Town", State: "Alaska"},
            GPA: [4.0, 4.0, 2],
            Date: theDate(),
            Average: getAverage([4.0, 4.0, 2])
        }


    ];


    function getAverage(gpas) {
        var addedNumbers = 0;

        for (i = 0; i < gpas.length; i++) {
            addedNumbers += gpas[i];
        }
        var average = addedNumbers / gpas.length;
        return average.toFixed(2);
    }


    logStuff(people);
    addPerson("Peter", "225 Peters Dr", "Petersburg", "New York", [3.5, 2.75, 3.25], theDate(), getAverage([3.5, 2.75, 3.25]));
    logStuff(people);


    function addPerson(name, street, city, state, gpa, date, avg) {
        console.log("This is where the new person is added" + "\n");
        var newPerson = {Name: name, Address: {Street: street, City: city, State: state}, GPA: gpa, Date: date, Average: avg};
        people.push(newPerson);
    }


    function logStuff(arr) {
        for (i = 0; i < arr.length; i++) {
            console.log(
                "Name: " + arr[i].Name + "\n" +
                    "Address: " + arr[i].Address.Street + " " + arr[i].Address.City + " " + arr[i].Address.State + "\n" +
                    "GPA: " + arr[i].GPA + "\n" +
                    "Date: " + arr[i].Date + "\n" +
                    "Average: " + arr[i].Average + "\n" +
                    "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
            );

        }
    }


    if (studentNumber == 0) {
        var name = document.querySelector("#name");
        var address = document.querySelector("#address");
        var GPA = document.querySelector("#gpa");
        var date = document.querySelector("#date");
        var average = document.querySelector("#gpaavg");

        name.innerHTML = "Name: " + people[0].Name;
        address.innerHTML = "Address: " + people[0].Address.Street + " " + people[0].Address.City + " " + people[0].Address.State;
        GPA.innerHTML = "GPA: " + people[0].GPA;
        date.innerHTML = "Date: " + people[0].Date;
        average.innerHTML = "Average: " + people[0].Average;
    }
    function onClick(e) {

        studentNumber++;


        if (studentNumber == 1) {
            name.innerHTML = "Name: " + people[1].Name;
            address.innerHTML = "Address: " + people[1].Address.Street + " " + people[1].Address.City + " " + people[1].Address.State;
            GPA.innerHTML = "GPA: " + people[1].GPA;
            date.innerHTML = "Date: " + people[1].Date;
            average.innerHTML = "Average: " + people[1].Average;
        } else if (studentNumber == 2) {
            name.innerHTML = "Name: " + people[2].Name;
            address.innerHTML = "Address: " + people[2].Address.Street + " " + people[2].Address.City + " " + people[2].Address.State;
            GPA.innerHTML = "GPA: " + people[2].GPA;
            date.innerHTML = "Date: " + people[2].Date;
            average.innerHTML = "Average: " + people[2].Average;
            button.innerHTML = "Done!";

            button.removeEventListener("click", onClick);

        }


    }


    function theDate() {
        var months = ["Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"];
        myDate = new Date();
        var day = myDate.getDate();
        var month = myDate.getMonth() + 1;
        var year = myDate.getFullYear();
        return month + "/" + day + "/" + year;
    }


})();