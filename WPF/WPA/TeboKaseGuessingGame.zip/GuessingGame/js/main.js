/**
 * GUESSING GAME:
 *
 * Created By:
 * Date:
 *
 * GUESSING GAME
 */

//Game variables
(function () {

    var button = document.querySelector("#btn");
    button.addEventListener("click", onClick);
    var Input = document.querySelector("#input");
    var text = document.querySelector("#output");

    var randomNumber = Math.round(Math.random() * 9) + 1;
    var counter = 0;
    var guesses = "";


    function onClick(e) {
        counter++;
        winnercheck();


}














        function winnercheck() {
if (counter == 4){text.innerHTML = "Sorry You've Lost";
                   button.removeEventListener("click", onClick)}
            else {

            if (Input.value < randomNumber) {
                text.innerHTML = "Your Number Is To Low!";
//
            } else if (Input.value > randomNumber) {
                text.innerHTML = "Your Number Is To High!";
//
            } else if (Input.value == randomNumber) {
                text.innerHTML = "You Got The Number Correct!";
                button.removeEventListener("click", onClick);
            }


        }
        }



})();